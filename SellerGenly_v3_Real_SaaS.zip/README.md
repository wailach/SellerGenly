# SellerGenly v3 — Real SaaS foundation

This is the production-oriented foundation for SellerGenly:
- Next.js 16 App Router
- Supabase Auth + Postgres + Row Level Security
- Server-side OpenAI Responses API endpoint
- Responsive dashboard, product analysis, calculator and pricing
- Secrets kept in server environment variables

## Important
This is a real SaaS codebase foundation, but it is not magically live until you connect your own services and deploy it. Do not put OPENAI_API_KEY in client-side code.

## 1. Create Supabase
Create a Supabase project. In SQL Editor, run `supabase/schema.sql`.
Then copy the project URL and publishable key into Vercel environment variables.

## 2. Configure Auth
Set the Supabase Site URL to your production URL. Use the confirmation route:
`/auth/confirm`

## 3. Configure AI
Add:
- OPENAI_API_KEY
- OPENAI_MODEL

Do not hard-code the model name. Choose a model currently available to your API account and put its exact ID in OPENAI_MODEL.

The app uses the OpenAI Responses API, not the retired Assistants API.

## 4. Deploy
Push this folder to GitHub, then import the repository into Vercel. Vercel detects Next.js automatically.

Environment variables:
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
OPENAI_API_KEY
OPENAI_MODEL
NEXT_PUBLIC_SITE_URL

After adding/changing environment variables, redeploy.

## 5. Next production milestones
1. Persist product create/edit/delete UI into Supabase.
2. Add usage limits by plan.
3. Add Stripe Checkout + customer portal + webhook.
4. Add real product research data sources/APIs.
5. Add analytics, error monitoring and abuse/rate limits.
6. Add custom domain sellergenly.com (or your chosen domain).
