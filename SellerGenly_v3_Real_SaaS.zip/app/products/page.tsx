 "use client";
import { useState } from "react";
export default function Products() {
  const [name,setName]=useState(""); const [cost,setCost]=useState("10"); const [price,setPrice]=useState("29"); const [analysis,setAnalysis]=useState(""); const [loading,setLoading]=useState(false);
  async function analyze(){setLoading(true);setAnalysis(""); const r=await fetch("/api/ai",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({productName:name,cost:Number(cost),price:Number(price),platform:"Etsy"})}); const j=await r.json(); setAnalysis(j.output||j.error||"No response"); setLoading(false);}
  return <main className="app-shell single"><section className="workspace"><header className="topbar"><div><span className="eyebrow">PRODUCT INTELLIGENCE</span><h1>Analyze a product</h1></div><a href="/dashboard" className="btn ghost">Dashboard</a></header>
    <div className="analysis-layout"><div className="panel form-panel"><h2>Product details</h2><label>Product name<input value={name} onChange={e=>setName(e.target.value)} placeholder="e.g. Personalized travel planner"/></label><div className="two"><label>Unit cost<input type="number" value={cost} onChange={e=>setCost(e.target.value)}/></label><label>Selling price<input type="number" value={price} onChange={e=>setPrice(e.target.value)}/></label></div><label>Platform<select><option>Etsy</option><option>Shopify</option><option>Amazon</option><option>KDP</option><option>POD</option></select></label><button className="btn primary big" onClick={analyze} disabled={loading||!name}>{loading?"Analyzing…":"Analyze with AI →"}</button></div>
    <div className="panel result"><span className="eyebrow">AI ANALYSIS</span><h2>{analysis?"Your opportunity report":"Your report will appear here"}</h2>{analysis?<pre>{analysis}</pre>:<p>Enter a product and price. SellerGenly will send the request to your secure server-side AI endpoint.</p>}</div></div>
  </section></main>;
}
